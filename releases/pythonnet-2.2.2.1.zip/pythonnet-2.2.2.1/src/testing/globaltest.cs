using System;

//========================================================================
// Supports units tests for access to types without a namespace.
//========================================================================

public class NoNamespaceType
{
}