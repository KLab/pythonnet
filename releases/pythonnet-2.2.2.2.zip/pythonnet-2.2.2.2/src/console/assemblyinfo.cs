using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyProduct("Python for .NET")]
[assembly: AssemblyVersion("2.4.2.7")]
[assembly: AssemblyTitle("Python Console")]
[assembly: AssemblyDefaultAlias("python.exe")]
[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: PermissionSet(SecurityAction.RequestMinimum,
    Name = "FullTrust")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCopyright("MIT License")]
[assembly: AssemblyFileVersion("2.0.0.4")]
[assembly: NeutralResourcesLanguage("en")]
